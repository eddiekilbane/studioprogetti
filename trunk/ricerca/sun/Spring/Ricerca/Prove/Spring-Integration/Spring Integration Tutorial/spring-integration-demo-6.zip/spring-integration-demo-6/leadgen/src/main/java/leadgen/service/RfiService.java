package leadgen.service;

import leadgen.model.Rfi;

public interface RfiService {
	
	void submitRfi(Rfi rfi);
}
