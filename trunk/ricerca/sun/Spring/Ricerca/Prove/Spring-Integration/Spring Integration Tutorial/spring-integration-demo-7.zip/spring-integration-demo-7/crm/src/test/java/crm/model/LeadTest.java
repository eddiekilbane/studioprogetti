package crm.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import crm.model.Lead;

public class LeadTest {
	
	@Test
	public void testGuessNamesFromFullName() {
		guessNamesFromFullName("Willie Wheeler", "Willie", "Wheeler");
		guessNamesFromFullName("Willie Wheeler ", "Willie", "Wheeler");
		guessNamesFromFullName("Willie  Wheeler", "Willie", "Wheeler");
		guessNamesFromFullName("\t\nWillie\t  \n\nWheeler \t  \n", "Willie", "Wheeler");
		guessNamesFromFullName("Peggy Sue Gerron", "Peggy Sue", "Gerron");
		guessNamesFromFullName("Peggy Sue  Gerron", "Peggy Sue", "Gerron");
		guessNamesFromFullName("Peggy  Sue Gerron", "Peggy Sue", "Gerron");
		guessNamesFromFullName("   Peggy  Sue   Gerron   ", "Peggy Sue", "Gerron");
		guessNamesFromFullName("  \n Peggy\tSue   Gerron   ", "Peggy Sue", "Gerron");
		guessNamesFromFullName("Joe Jolly-Johnson", "Joe", "Jolly-Johnson");
		guessNamesFromFullName("  Joe Jolly-Johnson", "Joe", "Jolly-Johnson");
		guessNamesFromFullName("  Joe Jolly-Johnson  ", "Joe", "Jolly-Johnson");
		guessNamesFromFullName("  Joe    Jolly-Johnson  ", "Joe", "Jolly-Johnson");
		guessNamesFromFullName("  \t \n\n\t Joe    \t \t Jolly-Johnson  \n", "Joe", "Jolly-Johnson");
		guessNamesFromFullName("Jim-Bob Jones", "Jim-Bob", "Jones");
		guessNamesFromFullName("Jim-Bob Jones ", "Jim-Bob", "Jones");
		guessNamesFromFullName("Jim-Bob  Jones", "Jim-Bob", "Jones");
		guessNamesFromFullName("  Jim-Bob  Jones ", "Jim-Bob", "Jones");
		guessNamesFromFullName("M.C. Escher", "M.C.", "Escher");
		guessNamesFromFullName("M. C. Escher", "M. C.", "Escher");
		guessNamesFromFullName(null, null, null);
		guessNamesFromFullName("", null, null);
		guessNamesFromFullName("  ", null, null);
		guessNamesFromFullName("\t", null, null);
		guessNamesFromFullName("  \t\n \t ", null, null);
		guessNamesFromFullName("Cher", "Cher", null);
		guessNamesFromFullName(" Cher", "Cher", null);
		guessNamesFromFullName(" \tCher \n", "Cher", null);
	}
	
	private static void guessNamesFromFullName(String fullName,
			String expectedFirstName, String expectedLastName) {
		
		Lead lead = new Lead();
		lead.guessNamesFromFullName(fullName);
		assertEquals(expectedFirstName, lead.getFirstName());
		assertEquals(expectedLastName, lead.getLastName());
	}
	
	@Test
	public void testIsInternational() {
		Lead lead = new Lead();
		
		lead.setCountry(null);
		assertFalse(lead.isInternational());
		
		lead.setCountry("US");
		assertFalse(lead.isInternational());
		
		lead.setCountry("MX");
		assertTrue(lead.isInternational());
	}
}
