package crm.service;

import crm.model.Lead;

public interface LeadService {
	
	void createLead(Lead lead);
}
